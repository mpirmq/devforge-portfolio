@echo off
cd /d "%~dp0"
python --version >nul 2>&1
if errorlevel 1 (py app.py) else (python app.py)
pause
