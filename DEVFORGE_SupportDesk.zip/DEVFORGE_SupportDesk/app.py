"""DEVFORGE SupportDesk — local, single-user application. Python 3.10+."""
import csv, io, json, os, secrets, socket, sqlite3, time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
import urllib.request

ROOT=Path(__file__).parent
DB=Path(os.environ.get('SUPPORTDESK_DB',str(ROOT/'supportdesk.sqlite3')))
TOKEN=secrets.token_urlsafe(32)
ALLOWED={'example.com','www.python.org','github.com'}
STATUSES={'Open','In progress','Resolved'}
PRIORITIES={'Low','Medium','High','Critical'}
def now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')
def connect():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); return c
def init():
    with connect() as c:
        c.executescript('''CREATE TABLE IF NOT EXISTS tickets(id INTEGER PRIMARY KEY,title TEXT NOT NULL,description TEXT NOT NULL,category TEXT NOT NULL,priority TEXT NOT NULL,status TEXT NOT NULL,created TEXT NOT NULL,updated TEXT NOT NULL,resolved TEXT);
        CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY,ticket_id INTEGER NOT NULL REFERENCES tickets(id),kind TEXT NOT NULL,body TEXT NOT NULL,created TEXT NOT NULL);''')
def event(c,tid,kind,body): c.execute('INSERT INTO events(ticket_id,kind,body,created) VALUES(?,?,?,?)',(tid,kind,body,now()))
def create(data):
    title=str(data.get('title','')).strip(); description=str(data.get('description','')).strip()
    category=str(data.get('category','General')); priority=data.get('priority','Medium')
    if not title or len(title)>150 or not description or len(description)>10000 or len(category)>80 or priority not in PRIORITIES: raise ValueError('Enter a title (1–150), description (1–10000) and valid priority.')
    with connect() as c:
        t=now(); cur=c.execute('INSERT INTO tickets(title,description,category,priority,status,created,updated) VALUES(?,?,?,?,?,?,?)',(title,description,category,priority,'Open',t,t)); tid=cur.lastrowid; event(c,tid,'created','Ticket created'); return tid

def diagnose(host,mode):
    if host not in ALLOWED or mode not in {'dns','tcp','http'}: raise ValueError('Select an allowed target and diagnostic.')
    start=time.monotonic()
    # Every resolved address must be public; never follow HTTP redirects.
    import ipaddress
    addresses=sorted({r[4][0] for r in socket.getaddrinfo(host,443,type=socket.SOCK_STREAM)})
    if not addresses or any(not ipaddress.ip_address(a).is_global for a in addresses): raise ValueError('Target does not resolve exclusively to public addresses.')
    if mode=='dns': result='DNS: '+', '.join(addresses)
    elif mode=='tcp':
        with socket.create_connection((addresses[0],443),timeout=4): result='TCP port 443 reachable'
    else:
        # Pin the connection to the checked IP while retaining TLS hostname validation.
        import http.client, ssl
        class Pinned(http.client.HTTPSConnection):
            def connect(self):
                raw=socket.create_connection((addresses[0],443),timeout=4)
                self.sock=ssl.create_default_context().wrap_socket(raw,server_hostname=host)
        conn=Pinned(host,timeout=4)
        try:
            conn.request('HEAD','/',headers={'User-Agent':'DEVFORGE-SupportDesk/1.0'}); resp=conn.getresponse(); result=f'HTTP {resp.status} {resp.reason} (redirects not followed)'
        finally: conn.close()
    return {'target':host,'mode':mode,'result':result,'elapsed_ms':round((time.monotonic()-start)*1000),'checked_at':now()}

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def respond(self,value,status=200,kind='application/json; charset=utf-8'):
        body=value if isinstance(value,bytes) else json.dumps(value).encode()
        self.send_response(status); self.send_header('Content-Type',kind); self.send_header('Content-Length',str(len(body))); self.send_header('Cache-Control','no-store'); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Content-Security-Policy',"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'"); self.end_headers(); self.wfile.write(body)
    def valid_host(self): return self.headers.get('Host')==f'127.0.0.1:{self.server.server_port}'
    def do_GET(self):
        if not self.valid_host(): return self.respond({'error':'Use the displayed localhost URL'},403)
        path=urlsplit(self.path).path
        if path=='/': return self.respond((ROOT/'index.html').read_bytes(),kind='text/html; charset=utf-8')
        if path=='/ui.js': return self.respond((ROOT/'ui.js').read_bytes(),kind='text/javascript; charset=utf-8')
        if path=='/api/session': return self.respond({'token':TOKEN,'targets':sorted(ALLOWED)})
        with connect() as c:
            if path=='/api/tickets':
                return self.respond([dict(r) for r in c.execute('SELECT * FROM tickets ORDER BY id DESC')])
            if path=='/api/export':
                s=io.StringIO(); w=csv.writer(s); w.writerow(['ID','Title','Category','Priority','Status','Created','Resolved'])
                for r in c.execute('SELECT * FROM tickets ORDER BY id'):
                    vals=[r[k] or '' for k in ['id','title','category','priority','status','created','resolved']]
                    w.writerow(["'"+v if isinstance(v,str) and v.startswith(('=','+','-','@','\t','\r')) else v for v in vals])
                return self.respond(s.getvalue().encode('utf-8-sig'),kind='text/csv; charset=utf-8')
            if path.startswith('/api/tickets/'):
                try: tid=int(path.rsplit('/',1)[1])
                except ValueError: return self.respond({'error':'Invalid ID'},400)
                r=c.execute('SELECT * FROM tickets WHERE id=?',(tid,)).fetchone()
                if not r:return self.respond({'error':'Not found'},404)
                return self.respond({'ticket':dict(r),'events':[dict(x) for x in c.execute('SELECT * FROM events WHERE ticket_id=? ORDER BY id',(tid,))]})
        self.respond({'error':'Not found'},404)
    def do_POST(self):
        if not self.valid_host() or not secrets.compare_digest(self.headers.get('X-CSRF-Token',''),TOKEN): return self.respond({'error':'Invalid session'},403)
        try:
            n=int(self.headers.get('Content-Length','0'))
            if not 0<n<=20000: raise ValueError('Invalid request size')
            data=json.loads(self.rfile.read(n)); path=urlsplit(self.path).path
            if not isinstance(data,dict): raise ValueError('Expected JSON object')
            if path=='/api/tickets': return self.respond({'id':create(data)},201)
            if path=='/api/demo':
                with connect() as c:
                    if c.execute('SELECT count(*) FROM tickets').fetchone()[0]: raise ValueError('Demo data can only be added to an empty database.')
                for t,d,cat,p in [('Website unavailable','Fictional customer cannot open the company website.','Network','High'),('CSV import duplicates','Fictional import contains duplicate records.','Software','Medium'),('New workstation setup','Prepare a checklist for a fictional new employee.','Hardware','Low')]: create({'title':t,'description':d,'category':cat,'priority':p})
                return self.respond({'ok':True})
            tid=int(data.get('ticket_id',0))
            with connect() as c:
                r=c.execute('SELECT * FROM tickets WHERE id=?',(tid,)).fetchone()
                if not r: return self.respond({'error':'Ticket not found'},404)
                if path=='/api/update':
                    status=data.get('status'); priority=data.get('priority'); note=str(data.get('note','')).strip()
                    if status not in STATUSES or priority not in PRIORITIES or len(note)>10000: raise ValueError('Invalid status, priority or note')
                    if status=='Resolved' and r['status']!='Resolved' and not note: raise ValueError('Describe the solution before resolving.')
                    if status!=r['status']: event(c,tid,'status',r['status']+' → '+status)
                    if priority!=r['priority']:event(c,tid,'priority',r['priority']+' → '+priority)
                    if note:event(c,tid,'note',note)
                    c.execute('UPDATE tickets SET status=?,priority=?,updated=?,resolved=? WHERE id=?',(status,priority,now(),(r['resolved'] or now()) if status=='Resolved' else None,tid))
                elif path=='/api/diagnose':
                    try: result=diagnose(data.get('target'),data.get('mode'))
                    except (OSError,ValueError) as e: result={'error':str(e)[:300],'checked_at':now()}
                    event(c,tid,'diagnostic',json.dumps(result)); self.respond(result); return
                else:return self.respond({'error':'Not found'},404)
            return self.respond({'ok':True})
        except (ValueError,TypeError,KeyError,json.JSONDecodeError) as e:self.respond({'error':str(e)},400)
        except Exception:self.respond({'error':'Internal error; check local database permissions.'},500)

if __name__=='__main__':
    init(); server=ThreadingHTTPServer(('127.0.0.1',8765),Handler)
    print('DEVFORGE SupportDesk: http://127.0.0.1:8765 — Ctrl+C to stop',flush=True)
    try:server.serve_forever()
    except KeyboardInterrupt:server.server_close()
