import unittest,tempfile,threading,json,urllib.request,urllib.error
from pathlib import Path
import app
class Workflow(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();app.DB=Path(self.tmp.name)/'test.sqlite3';app.init();self.s=app.ThreadingHTTPServer(('127.0.0.1',0),app.Handler);threading.Thread(target=self.s.serve_forever,daemon=True).start();self.url=f'http://127.0.0.1:{self.s.server_port}'
 def tearDown(self):self.s.shutdown();self.s.server_close();self.tmp.cleanup()
 def request(self,path,data=None,token=True):
  req=urllib.request.Request(self.url+path,data=json.dumps(data).encode() if data is not None else None,headers={'X-CSRF-Token':app.TOKEN if token else '', 'Content-Type':'application/json'})
  with urllib.request.urlopen(req) as r:return json.load(r)
 def test_full_workflow(self):
  t=self.request('/api/tickets',{'title':'Demo','description':'Fictional issue'})['id']
  self.request('/api/update',{'ticket_id':t,'status':'In progress','priority':'High','note':'Investigating'})
  with self.assertRaises(urllib.error.HTTPError) as e:self.request('/api/update',{'ticket_id':t,'status':'Resolved','priority':'High','note':''})
  self.assertEqual(e.exception.code,400)
  self.request('/api/update',{'ticket_id':t,'status':'Resolved','priority':'High','note':'Fixed and verified'})
  d=self.request('/api/tickets/'+str(t));self.assertEqual(d['ticket']['status'],'Resolved');self.assertTrue(d['ticket']['resolved']);self.assertEqual(len(d['events']),6)
  app.init();self.assertEqual(len(self.request('/api/tickets')),1)
 def test_validation_and_csrf(self):
  with self.assertRaises(urllib.error.HTTPError) as e:self.request('/api/tickets',{'title':'x','description':'x'},False)
  self.assertEqual(e.exception.code,403)
  with self.assertRaises(urllib.error.HTTPError):self.request('/api/tickets',{'title':'','description':'x'})
 def test_diagnostic_allowlist(self):
  with self.assertRaises(ValueError):app.diagnose('127.0.0.1','http')
 def test_demo_once(self):
  self.request('/api/demo',{});self.assertEqual(len(self.request('/api/tickets')),3)
  with self.assertRaises(urllib.error.HTTPError):self.request('/api/demo',{})
if __name__=='__main__':unittest.main()
