# DEVFORGE SupportDesk

Personal portfolio project. A local, single-user IT ticket workspace with SQLite persistence, activity history, CSV export and restricted DNS/TCP/HTTPS diagnostics. No client/employer data is included.

## Windows quick start
1. Install Python 3.10 or newer from python.org. Enable Python in PATH during installation.
2. Extract this entire archive into a writable folder.
3. Double-click `start.bat` or run `python app.py` in that folder.
4. Open **http://127.0.0.1:8765**. The exact address matters.
5. Click **Load fictional demo tickets**, or create your own ticket.
6. Stop the app with Ctrl+C in its terminal.

No pip packages, account, payment or cloud service is required. If `python` opens Microsoft Store or does not run, use `py app.py` after installing Python. This app does not install Python itself.

## Features
- Create tickets; search and filter by status/priority.
- Change priority, progress status, add notes; a resolution note is required when resolving.
- Persistent SQLite database (`supportdesk.sqlite3`, created on first launch).
- Activity history including diagnosis results and errors.
- Dashboard counts and average time from creation to resolution (minutes).
- Export all tickets as CSV, including resolved tickets.
- DNS, TCP 443 and HTTPS HEAD checks for example.com, www.python.org, github.com.

Diagnostics operate from your machine, not the reported user's device. DNS resolution follows OS resolver timing; TCP and HTTPS have four-second connection timeouts. Network failures are recorded as results. No ping, port-range scan, private network checks, arbitrary URLs or redirect following. Checks require internet access. This is a troubleshooting demonstration, not a security audit.

## Architecture
Python standard library HTTP server + SQLite + plain JavaScript/HTML/CSS. The app deliberately uses no external framework to make local setup reproducible. FastAPI is **not** used in this version.

API: GET `/api/tickets`, GET `/api/tickets/{id}`, POST `/api/tickets`, POST `/api/update`, POST `/api/diagnose`, POST `/api/demo`, GET `/api/export`. Mutation requests require the locally issued CSRF token.

## Deployment boundary
Designed for one trusted user on one computer. The server binds only to 127.0.0.1 and validates Host. It has no multi-user authentication, authorization, encryption-at-rest or production deployment configuration. Do not expose it to the internet, use real patient/customer information or treat this prototype as an enterprise service desk. Back up the database after stopping the application. Do not commit your database to Git.

## Tests
`python -m unittest -v` exercises creation, validation, update API, resolution, persistence and request protection without external network access.

## Deutsch
SupportDesk ist ein persönliches Portfolio-Projekt: lokale IT-Tickets, Prioritäten, Statusverlauf, Lösungsnotizen, SQLite, CSV-Export und eingeschränkte Netzwerkdiagnostik. Start: `python app.py`, dann http://127.0.0.1:8765 öffnen. Die Demo verwendet ausschließlich erfundene Daten. Keine kommerzielle Referenz und keine produktionsfertige Mehrbenutzerlösung.

## Русский
Это готовая локальная учебная версия для одного пользователя. После установки Python запустите start.bat и откройте указанный адрес. Кнопка демо создаёт три вымышленные заявки. Для закрытия заявки добавьте описание решения. База сохраняется рядом с программой. В портфолио указывайте проект как личный прототип, а не работу для заказчика.
